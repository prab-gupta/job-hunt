# Do not repeat — master dedupe list

**348 companies.** Built 12 August 2026 from the run logs, every tab of every workbook generated, and the project docs.

**Check every candidate against this list before applying.** It has already caught three repeats: CityZ (join.com's own banner confirmed "You've applied on Aug 7"), Tangible, and n8n.

Names are normalised to lower case with legal suffixes stripped, so match loosely. Two known false-positive traps: **Postman** and **GitHub** appear because they are tools on his own CV, not because he applied there.

The live version is the **"Do not repeat"** tab of `Role shortlist - 8 Aug 2026.xlsx`, and the raw file is `DEDUPE.txt` in the working folder.

---

0hands · 1 capco poland · 1 no public code · 2 no german
2 otonomee x2 · 3 pigment · 3 your salary number · 4 reasonable ai
5 elevenlabs · absorb · account required  joincom · ace workflow
action1 · activecampaign · actually live when i opened them · adaptyv
aggregator mirrors are not verification · aircall · akka · alertmedia
alignerr · all four applications without you touching a form · altamira · amenitiz
amplitude · answers only he has · aoe · aplayers
appfire · applied to today · apply link could not be found · archie
arize ai · arkipel · ascending ai · aticco
atlantis dx · atmen solutions · atrix · attio
augment · avery · axiomatic ai · axmed
bas · ben · betahaus · beumer
blocked or needing him · bloomreach · board renders metadata only  workable · bob w
both shortlists are worked through · brief · camunda · candidate
capco poland · captcha on submit · cargovibe · checkly
claims filled fields are missing · clarasight · clera · cloudbeds
cloudworks · cobot · codekeeper · codex
cohere · colour key · commercetools · content automation engineer
contradictory eligibility could not resolve · copernico · coworked · coworkies
cresta · customerio · cv upload unreachable  smartrecruiters · dada energy srl
dash0 · databento · datacor · dead on arrival
decodifai · dedupe source of truth · deep dive  12 august 2026 · deepl
deeploi · deeploy · deliverect · deskimo
dexter health · digitalcube · digitalgenius · distru
docplanner · doit international · dont sound machinewritten · duvo
dwelly · easy8 · ecoonline · edra
eggai · elevenlabs · eligibility mix · ema
eneba · enode · epilot · everything here is blocked on you not on the roles
firecrawl · fit · fit 100 · flexascom
flowspacelike platform leads · flowspacelike platforms · forward deployed engineer  focused sweep 8 august 2026 · four rows are a decision not a blocker
four rows need one fact from you · freeday · freedom24 · fueled
general leads not applied to yet · gensyn · getyourguide · github profile
gitlab · goldsky · goodspeed studio · gorilla
gtm base · gwi · harness · hexa
hicx · highest fit score general leads · highest fit score platform leads · hipeople
holtzbrinck · hometogo · huckletree · iceye
idnow · ignores programmatic valuesetting · impact hub · intercom
istari · italy is a named remote location · jamie · jetbrains
jimdo · job search  state of play 6 august 2026 · job search  state of play end of 6 august 2026 · jobgether
kadoa · kairos · kentik · kfs
laioutr · lakera · langfuse · language
languagewire · laravel · launchmetrics · leapforce
lighthouse · lightning ai · linear · linkedin finds
linkedin finds unopened queue · lleverage · lleverageai · lodgify
loomya · lovable · luma ai · mailerlite
makeitfuture · makersite · measure · median fit score general leads
meticulous · mgid · mindrift · mindspace
miodottore · mistral ai · moneyfarm · more nutrition
morning · musixmatch · myedspace · n8n
neara · nearform · nebor · needs a fact only you have
needs you or blocked · netguru · new leads not applied to yet · no truthful option on a closed dropdown
not applicable · notable drops · novosafe · nozomi networks
nuite · nuwacom · of those he can clear himself in a browser · of those open to both a job and paid project work
of those postings that have since closed · of those sent on 6 august · of those tier 1 · of those waiting on words only he can write
olx · ommax · ophelos · opply
optix · opus · oryn · otherworldly
otonomee · outliant · outreach targets  companies to approach directly · outreach targets companies to approach directly
page would not render  ashby · paires · parloa · passport country
pay where it was disclosed · peopleix · pigment · pinnipedia
pliant · pooldayai · posthog · postman
pubnub · qdrant · quadrivia · queries run
quicknode · raw candidates · raw candidates seen · raw leads  surfaced this sweep not individually verified
reasonable ai · reedsy · reflection · reflow
released · remofirst · remote people · returned as verified by the sweeps
reverse · revos · rithum · roboyo
rossum · salescaptain · salesforce · saleshax consulting
saleslift studio · satispay · scale ai · scoring
seamflow · sera · sera intelligence · shaman
shippeo · shippypro · siena ai · signicat
skip joincom · skipped only because the form wants a cover letter · soji ai · solveai
sourcegraph · sources swept · space inch · spacebring
spacent · spacexai · speechmatics · spyrosoft
standing rules applied · starbridge · stratos · stx next
sunday natural · supaapps · supabase · super
supportyourapp · surge ai · survived the filters · swans
taktile · talent garden · tandem health · tangible
taxfix · teleport · telnyx · tenex
tensorops · the current workbook · the cv goes on every application · the flex
the only cv to send · the quality  esn · three italian roles behind indeed · tier 1
tier 1 is now 94 roles · tier 1 workable from venice today · tier 2 · tier 3
tiugo · toloka ai · total leads on this workbook · total leads still open on this workbook
treatwell · unframe · upflex · verification column
verified live before listing · vibiz · voids technology · vonage
watch sixts board for a repost · watchouts column · wayflyer · weaviate
where the new leads came from · wiz · work basis mix · workboard
workfloows · xai · yes · yld
zapfloor · zauber · zauber technology · zeotap